
<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8" />
<meta name='viewport' content='width=device-width, initial-scale=1.0' />
<meta http-equiv='X-UA-Compatible' content='IE=edge' />
<script>
var gform;gform||(document.addEventListener("gform_main_scripts_loaded",function(){gform.scriptsLoaded=!0}),window.addEventListener("DOMContentLoaded",function(){gform.domLoaded=!0}),gform={domLoaded:!1,scriptsLoaded:!1,initializeOnLoaded:function(o){gform.domLoaded&&gform.scriptsLoaded?o():!gform.domLoaded&&gform.scriptsLoaded?window.addEventListener("DOMContentLoaded",o):document.addEventListener("gform_main_scripts_loaded",o)},hooks:{action:{},filter:{}},addAction:function(o,r,n,t){gform.addHook("action",o,r,n,t)},addFilter:function(o,r,n,t){gform.addHook("filter",o,r,n,t)},doAction:function(o){gform.doHook("action",o,arguments)},applyFilters:function(o){return gform.doHook("filter",o,arguments)},removeAction:function(o,r){gform.removeHook("action",o,r)},removeFilter:function(o,r,n){gform.removeHook("filter",o,r,n)},addHook:function(o,r,n,t,i){null==gform.hooks[o][r]&&(gform.hooks[o][r]=[]);var e=gform.hooks[o][r];null==i&&(i=r+"_"+e.length),gform.hooks[o][r].push({tag:i,callable:n,priority:t=null==t?10:t})},doHook:function(o,r,n){if(n=Array.prototype.slice.call(n,1),null!=gform.hooks[o][r]){var t,i=gform.hooks[o][r];i.sort(function(o,r){return o.priority-r.priority});for(var e=0;e<i.length;e++)"function"!=typeof(t=i[e].callable)&&(t=window[t]),"action"==o?t.apply(null,n):n[0]=t.apply(null,n)}if("filter"==o)return n[0]},removeHook:function(o,r,n,t){if(null!=gform.hooks[o][r])for(var i=gform.hooks[o][r],e=i.length-1;0<=e;e--)null!=t&&t!=i[e].tag||null!=n&&n!=i[e].priority||i.splice(e,1)}});
</script>

<link rel="profile" href="https://gmpg.org/xfn/11" />
<meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />

	<!-- This site is optimized with the Yoast SEO plugin v17.5 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Your Payment Has Been Successfully Received</title>
	<link rel="canonical" href="https://brstore.us" />
	<meta property="og:locale" content="en_US" />
	<meta property="og:type" content="article" />
	<meta property="og:title" content="Your Payment Has Been Successfully Received" />
	<meta property="og:description" content="Thank You! Your payment was successful Please check your email inbox for a confirmation email regarding your recent purchase. Please give it up to 15 minutes to arrive (make sure you check your Spam Folder if you have not received it). If you have any questions or concerns feel free to contact support here. Thank&hellip;" />
	<meta property="og:url" content="https://brstore.us" />
	<meta property="og:site_name" content="Automation Bridge" />
	<meta property="article:modified_time" content="2020-05-08T00:00:25+00:00" />
	<meta property="og:image" content="https://automationbridge.com/wp-content/uploads/2017/01/ab-logo-orange.svg" />
	<meta name="twitter:card" content="summary_large_image" />
    <meta http-equiv="refresh" content="10;url=https://technology.brstore.us/pricing/" />

	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"Organization","@id":"https://automationbridge.com/#organization","name":"Automation Bridge","url":"https://automationbridge.com/","sameAs":[],"logo":{"@type":"ImageObject","@id":"https://automationbridge.com/#logo","inLanguage":"en-US","url":"https://automationbridge.com/wp-content/uploads/2016/04/ab-logo.png","contentUrl":"https://automationbridge.com/wp-content/uploads/2016/04/ab-logo.png","width":320,"height":60,"caption":"Automation Bridge"},"image":{"@id":"https://automationbridge.com/#logo"}},{"@type":"WebSite","@id":"https://automationbridge.com/#website","url":"https://automationbridge.com/","name":"Automation Bridge","description":"Grow your business online...automatically","publisher":{"@id":"https://automationbridge.com/#organization"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://automationbridge.com/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"en-US"},{"@type":"ImageObject","@id":"https://automationbridge.com/success/#primaryimage","inLanguage":"en-US","url":"https://automationbridge.com/wp-content/uploads/2017/01/ab-logo-orange.svg","contentUrl":"https://automationbridge.com/wp-content/uploads/2017/01/ab-logo-orange.svg","caption":"Automation Bridge - Grow Your Business with Marketing Automation"},{"@type":"WebPage","@id":"https://automationbridge.com/success/#webpage","url":"https://automationbridge.com/success/","name":"Your Payment Has Been Successfully Received","isPartOf":{"@id":"https://automationbridge.com/#website"},"primaryImageOfPage":{"@id":"https://automationbridge.com/success/#primaryimage"},"datePublished":"2017-04-30T03:29:07+00:00","dateModified":"2020-05-08T00:00:25+00:00","breadcrumb":{"@id":"https://automationbridge.com/success/#breadcrumb"},"inLanguage":"en-US","potentialAction":[{"@type":"ReadAction","target":["https://automationbridge.com/success/"]}]},{"@type":"BreadcrumbList","@id":"https://automationbridge.com/success/#breadcrumb","itemListElement":[{"@type":"ListItem","position":1,"name":"Home","item":"https://automationbridge.com/"},{"@type":"ListItem","position":2,"name":"Payment Completion"}]}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link href='https://fonts.gstatic.com' crossorigin rel='preconnect' />
<link rel="alternate" type="application/rss+xml" title="Automation Bridge &raquo; Feed" href="https://automationbridge.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Automation Bridge &raquo; Comments Feed" href="https://automationbridge.com/comments/feed/" />
<link rel="preload" href="https://automationbridge.com/wp-content/plugins/bb-plugin/fonts/fontawesome/5.15.3/webfonts/fa-brands-400.woff2" as="font" type="font/woff2" crossorigin="anonymous">
<link rel="preload" href="https://automationbridge.com/wp-content/plugins/bb-plugin/fonts/fontawesome/5.15.3/webfonts/fa-solid-900.woff2" as="font" type="font/woff2" crossorigin="anonymous">
<link rel="preload" href="https://automationbridge.com/wp-content/plugins/bb-plugin/fonts/fontawesome/5.15.3/webfonts/fa-regular-400.woff2" as="font" type="font/woff2" crossorigin="anonymous">
		<script>
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/automationbridge.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.1"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style>
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='https://automationbridge.com/wp-includes/css/dist/block-library/style.min.css?ver=5.8.1' media='all' />
<style id='wp-block-library-theme-inline-css'>
#start-resizable-editor-section{display:none}.wp-block-audio figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-audio figcaption{color:hsla(0,0%,100%,.65)}.wp-block-code{font-family:Menlo,Consolas,monaco,monospace;color:#1e1e1e;padding:.8em 1em;border:1px solid #ddd;border-radius:4px}.wp-block-embed figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-embed figcaption{color:hsla(0,0%,100%,.65)}.blocks-gallery-caption{color:#555;font-size:13px;text-align:center}.is-dark-theme .blocks-gallery-caption{color:hsla(0,0%,100%,.65)}.wp-block-image figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-image figcaption{color:hsla(0,0%,100%,.65)}.wp-block-pullquote{border-top:4px solid;border-bottom:4px solid;margin-bottom:1.75em;color:currentColor}.wp-block-pullquote__citation,.wp-block-pullquote cite,.wp-block-pullquote footer{color:currentColor;text-transform:uppercase;font-size:.8125em;font-style:normal}.wp-block-quote{border-left:.25em solid;margin:0 0 1.75em;padding-left:1em}.wp-block-quote cite,.wp-block-quote footer{color:currentColor;font-size:.8125em;position:relative;font-style:normal}.wp-block-quote.has-text-align-right{border-left:none;border-right:.25em solid;padding-left:0;padding-right:1em}.wp-block-quote.has-text-align-center{border:none;padding-left:0}.wp-block-quote.is-large,.wp-block-quote.is-style-large{border:none}.wp-block-search .wp-block-search__label{font-weight:700}.wp-block-group.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}.wp-block-separator{border:none;border-bottom:2px solid;margin-left:auto;margin-right:auto;opacity:.4}.wp-block-separator:not(.is-style-wide):not(.is-style-dots){width:100px}.wp-block-separator.has-background:not(.is-style-dots){border-bottom:none;height:1px}.wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots){height:2px}.wp-block-table thead{border-bottom:3px solid}.wp-block-table tfoot{border-top:3px solid}.wp-block-table td,.wp-block-table th{padding:.5em;border:1px solid;word-break:normal}.wp-block-table figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-table figcaption{color:hsla(0,0%,100%,.65)}.wp-block-video figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-video figcaption{color:hsla(0,0%,100%,.65)}.wp-block-template-part.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}#end-resizable-editor-section{display:none}
</style>
<link rel='stylesheet' id='ultimate-icons-css'  href='https://automationbridge.com/wp-content/uploads/bb-plugin/icons/ultimate-icons/style.css?ver=2.5.0.2' media='all' />
<link rel='stylesheet' id='font-awesome-v4shim-css'  href='https://automationbridge.com/wp-content/plugins/types/vendor/toolset/toolset-common/res/lib/font-awesome/css/v4-shims.css?ver=5.13.0' media='screen' />
<link rel='stylesheet' id='font-awesome-css'  href='https://automationbridge.com/wp-content/plugins/types/vendor/toolset/toolset-common/res/lib/font-awesome/css/all.css?ver=5.13.0' media='screen' />
<link rel='stylesheet' id='fl-builder-layout-5793-css'  href='https://automationbridge.com/wp-content/uploads/bb-plugin/cache/5793-layout.css?ver=ae0e053a063cf30bcbccd00e9678dc43' media='all' />
<link rel='stylesheet' id='ssp-recent-episodes-css'  href='https://automationbridge.com/wp-content/plugins/seriously-simple-podcasting/assets/css/recent-episodes.css?ver=2.9.5' media='all' />
<link rel='stylesheet' id='font-awesome-5-css'  href='https://automationbridge.com/wp-content/plugins/bb-plugin/fonts/fontawesome/5.15.3/css/all.min.css?ver=2.5.0.2' media='all' />
<link rel='stylesheet' id='fl-builder-layout-bundle-4db142db1c49c0d60d0786c36942e545-css'  href='https://automationbridge.com/wp-content/uploads/bb-plugin/cache/4db142db1c49c0d60d0786c36942e545-layout-bundle.css?ver=2.5.0.2-1.3.3.1' media='all' />
<link rel='stylesheet' id='jquery-magnificpopup-css'  href='https://automationbridge.com/wp-content/plugins/bb-plugin/css/jquery.magnificpopup.css?ver=2.5.0.2' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='https://automationbridge.com/wp-content/themes/bb-theme/css/bootstrap.min.css?ver=1.7.9' media='all' />
<link rel='stylesheet' id='fl-automator-skin-css'  href='https://automationbridge.com/wp-content/uploads/bb-theme/skin-614cf103718cc.css?ver=1.7.9' media='all' />
<link rel='stylesheet' id='fl-child-theme-css'  href='https://automationbridge.com/wp-content/themes/bb-theme-child/style.css?ver=5.8.1' media='all' />
<link rel='stylesheet' id='fl-builder-google-fonts-dbeb1692807bb52d74f300ffefa31350-css'  href='//fonts.googleapis.com/css?family=IBM+Plex+Sans%3A300%2C400%2C700%7CPoppins%3A500%7CRoboto%3A400%2C700%2Cnormal%2C300&#038;ver=5.8.1' media='all' />
<script src='https://automationbridge.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script src='https://automationbridge.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script src='https://automationbridge.com/wp-includes/js/imagesloaded.min.js?ver=5.8.1' id='imagesloaded-js'></script>
<link rel="https://api.w.org/" href="https://automationbridge.com/wp-json/" /><link rel="alternate" type="application/json" href="https://automationbridge.com/wp-json/wp/v2/pages/5793" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://automationbridge.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://automationbridge.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.8.1" />
<meta name="generator" content="Seriously Simple Podcasting 2.9.5" />
<link rel='shortlink' href='https://automationbridge.com/?p=5793' />
<link rel="alternate" type="application/json+oembed" href="https://automationbridge.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fautomationbridge.com%2Fsuccess%2F" />
<link rel="alternate" type="text/xml+oembed" href="https://automationbridge.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fautomationbridge.com%2Fsuccess%2F&#038;format=xml" />

<link rel="alternate" type="application/rss+xml" title="Podcast RSS feed" href="https://automationbridge.com/feed/podcast" />

		<style id="wp-custom-css">
			@media screen and (min-width:480px) {
.col-3 {width:32%;float:left;clear:none!important;margin-right:10px;}
.col-2 {width:48%;float:left;clear:none!important;margin-right:10px;}
.col-3.last, .col-2.last {margin-right:0;}
}

.fl-page-header-row.row {margin:0}

#postcontent div p strong,
#postcontent div p b{
    color: #000000;
}

blockquote:before {
		content: '';
    display: block;
    top: 0;
    left: 0;
    width: 40px;
    height: 40px;
    border-color: #66c46e;
    border-style: solid;
    border-width: 6px 0 0 6px;
}

blockquote p {padding:0 40px;}
/*
CSS Migrated from BB theme:
*/
.info-quote {
	background:#f7f7f7;
	padding:20px;
	margin: 20px auto;
	font-style:italic;
	font-size:15px;
	border-radius:8px;
	-webkit-border-radius:8px;
	-moz-border-radius:8px;
}

.wp-caption {
    background: none;
    border: none;
    max-width: 100%;
    padding: 0px;
    text-align: center;
	  color:#7a7a7a;
}

.wp-caption p.wp-caption-text {
    font-size: 14px;
    line-height: 17px;
    margin: 0;
    padding: 10px 5px 5px 5px;
}

.fl-logo-img {max-width:240px;}
.fl-page-nav .navbar-nav a {font-size:16px;font-weight:normal!important}

.fl-page-nav-right .fl-page-nav-wrap .navbar-nav > li > a:focus {color:#e96e2a;}

blockquote {
   /* border-color:#66c46e;*/
	  border:none;
	overflow:hidden;
	display:block;
	font-size:28px;
	text-align:left;
    font-weight:700;
    color:#111111;
	background:#fafafa;
	padding:0 0 40px;
	margin: 40px 0
}

blockquote p {
	line-height: 120%}

.divider {display:block;clear:both;border-top:3px solid #f1f1f1;margin:40px 0}

.gray-bg {background:#f5f5f5; border:3px solid #777777;}
.darkblue-bg {background:#020E24}

.img-border-gray {border: 5px solid #f5f5f5;}

a.no-undies {text-decoration:none;}

.fl-module-content a {word-break:break-word;}

.fl-post-meta-bottom {font-style:normal; font-size:14px;}
.fl-post-title {font-size:30px;}
.fl-page-nav-right .fl-page-header-logo {padding:20px 0;}
.fl-page-nav-right .fl-page-header-container,
.fl-page-nav-col {padding:0!important;}


h1,h2,h3,h4,h5,h6 {font-weight:bold;}

p {margin: 0 0 20px;}

a,
a:hover {color:#e96e2a;}

.fl-page-nav-right .fl-page-nav-wrap .navbar-nav > li.current-menu-item > a,
.fl-page-nav-right .fl-page-nav-wrap .navbar-nav > li > a:hover {color:#e96e2a;}

.fl-page-nav-right .fl-page-nav-wrap .navbar-nav > li > a {font-weight:lighter;}

.blog-stream h2 a {font-weight:normal;}
.blog-stream h2 a:hover {color:#333;}

@media (max-width:960px) {
    li.menu-item a {padding:15px 12px!important;margin-right:0px; text-align:center;}
}

@media (max-width:480px) {
    blockquote p {padding:0;}
}




		</style>
		<script id="fl-theme-custom-js"><script type="text/javascript">
(function (d,i,$) {
  $('input[name="' + i + '"]').attr('value', window.location.href);
})(document, 'field\[13\]', jQuery);
</script></script>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N54M99"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<script async src="https://js.convertflow.co/production/websites/6629.js"></script>

<link rel="image_src" href="https://automationbridge.com/wp-content/uploads/2019/12/All-Systems-Go-Social-Share-2-1.png" />
<link rel="canonical" href="https://automationbridge.com">

<meta name="facebook-domain-verification" content="z8wmcihe0gnj8ptpaw7thteymevvj8" />

</head>
<body class="page-template page-template-tpl-no-header-footer page-template-tpl-no-header-footer-php page page-id-5793 fl-builder fl-theme-builder-footer fl-theme-builder-header fl-framework-bootstrap fl-preset-default fl-full-width" itemscope="itemscope" itemtype="https://schema.org/WebPage">
<a aria-label="Skip to content" class="fl-screen-reader-text" href="#fl-main-content">Skip to content</a><div class="fl-page">
		<div id="fl-main-content" class="fl-page-content" itemprop="mainContentOfPage" role="main">

		
<div class="fl-content-full container">
	<div class="row">
		<div class="fl-content col-md-12">
			<article class="fl-post post-5793 page type-page status-publish hentry" id="fl-post-5793" itemscope="itemscope" itemtype="https://schema.org/CreativeWork">

			<div class="fl-post-content clearfix" itemprop="text">
		<div class="fl-builder-content fl-builder-content-5793 fl-builder-content-primary fl-builder-global-templates-locked" data-post-id="5793"><div class="fl-row fl-row-fixed-width fl-row-bg-none fl-node-590556458a661" data-node="590556458a661">
	<div class="fl-row-content-wrap">
								<div class="fl-row-content fl-row-fixed-width fl-node-content">
		
<div class="fl-col-group fl-node-590559af9098c" data-node="590559af9098c">
			<div class="fl-col fl-node-590559af90b30" data-node="590559af90b30">
	<div class="fl-col-content fl-node-content">
	<div class="fl-module fl-module-uabb-photo fl-node-59055679a2b7e" data-node="59055679a2b7e">
	<div class="fl-module-content fl-node-content">
		<div class="uabb-module-content uabb-photo
uabb-photo-align-center uabb-photo-mob-align-center" itemscope itemtype="https://schema.org/ImageObject">
	<div class="uabb-photo-content ">

				<img class="uabb-photo-img wp-image-5681 size-full" src="https://technology.brstore.us/bandr/footer.png" alt="Automation Bridge - Grow Your Business with Marketing Automation" title="ab-logo-orange" itemprop="image"  />

					</div>
	</div>
	</div>
</div>
	</div>
</div>
	</div>

<div class="fl-col-group fl-node-590556458c040" data-node="590556458c040">
			<div class="fl-col fl-node-590556458c15c fl-col-small" data-node="590556458c15c">
	<div class="fl-col-content fl-node-content">
		</div>
</div>
			<div class="fl-col fl-node-590556458c1a4" data-node="590556458c1a4">
	<div class="fl-col-content fl-node-content">
	<div class="fl-module fl-module-info-box fl-node-590558a4d3210" data-node="590558a4d3210">
	<div class="fl-module-content fl-node-content">
		<div class="uabb-module-content uabb-infobox infobox-center ">
	<div class="uabb-infobox-left-right-wrap">
	<div class="uabb-infobox-content"> 
			<div class='uabb-infobox-title-wrap'><h1 class="uabb-infobox-title-prefix">Thank You!</h1><h3 class="uabb-infobox-title">Your payment was successful</h3></div>		</div>	</div>
</div>
	</div>
</div>
<div class="fl-module fl-module-rich-text fl-node-59055ddf61b4c" data-node="59055ddf61b4c">
	<div class="fl-module-content fl-node-content">
		<div class="fl-rich-text">
	<p>Please check your email inbox for a confirmation email regarding your recent purchase.</p>
<p>Please give it up to 15 minutes to arrive (<em>make sure you check your Spam Folder if you have not received it</em>).</p>
<p>If you have any questions or concerns feel free to <a title="Email customer support" href="mailto:support@brstore.us" target="_blank" rel="noopener noreferrer">contact support here</a>.</p>
<p>Thank you so much for doing business with us,</p>
<p><strong>Build and Run</strong><br />
Tech Team</p>
</div>
	</div>
</div>
<div class="fl-module fl-module-html fl-node-59055f1eaebe9" data-node="59055f1eaebe9">
	<div class="fl-module-content fl-node-content">
		<div class="fl-html">
	</div>
	</div>
</div>
<div class="fl-module fl-module-html fl-node-59a19cfb5d80e" data-node="59a19cfb5d80e">
	<div class="fl-module-content fl-node-content">
		<div class="fl-html">
	</div>
	</div>
</div>
	</div>
</div>
			<div class="fl-col fl-node-590556458c1d5 fl-col-small" data-node="590556458c1d5">
	<div class="fl-col-content fl-node-content">
		</div>
</div>
	</div>
		</div>
	</div>
</div>
<div class="fl-row fl-row-fixed-width fl-row-bg-none fl-node-59055bd3d6232" data-node="59055bd3d6232">
	<div class="fl-row-content-wrap">
								<div class="fl-row-content fl-row-fixed-width fl-node-content">
		
<div class="fl-col-group fl-node-59055bd3daf53" data-node="59055bd3daf53">
			<div class="fl-col fl-node-59055bd3db04e" data-node="59055bd3db04e">
	<div class="fl-col-content fl-node-content">
	<div class="fl-module fl-module-heading fl-node-59055bd3d5f3a" data-node="59055bd3d5f3a">
	<div class="fl-module-content fl-node-content">
		<h6 class="fl-heading">
		<span class="fl-heading-text">©2021 B&R LLC. All Rights Reserved</span>
	</h6>
	</div>
</div>
	</div>
</div>
	</div>
		</div>
	</div>
</div>
</div><div class="uabb-js-breakpoint" style="display: none;"></div>	</div><!-- .fl-post-content -->
	
</article>

<!-- .fl-post -->
		</div>
	</div>
</div>


	</div><!-- .fl-page-content -->
		</div><!-- .fl-page -->
<link rel='stylesheet' id='fl-builder-google-fonts-c4cb17ef0322c33f793a9e95f454135b-css'  href='//fonts.googleapis.com/css?family=IBM+Plex+Sans%3A300%2C400%2C700%7CPoppins%3A500%7CRoboto%3Anormal%2C300%2C400%2C700&#038;ver=5.8.1' media='all' />
<script src='https://automationbridge.com/wp-content/uploads/bb-plugin/cache/5793-layout.js?ver=2af46a560d336ecf0951fbae1a0c8647' id='fl-builder-layout-5793-js'></script>
<script src='https://automationbridge.com/wp-content/plugins/bb-plugin/js/jquery.ba-throttle-debounce.min.js?ver=2.5.0.2' id='jquery-throttle-js'></script>
<script src='https://automationbridge.com/wp-content/uploads/bb-plugin/cache/48ac9fe56c421dcd405cb08fc820268a-layout-bundle.js?ver=2.5.0.2-1.3.3.1' id='fl-builder-layout-bundle-48ac9fe56c421dcd405cb08fc820268a-js'></script>
<script src='https://automationbridge.com/wp-content/plugins/bb-plugin/js/jquery.magnificpopup.js?ver=2.5.0.2' id='jquery-magnificpopup-js'></script>
<script src='https://automationbridge.com/wp-content/themes/bb-theme/js/bootstrap.min.js?ver=1.7.9' id='bootstrap-js'></script>
<script id='fl-automator-js-extra'>
var themeopts = {"medium_breakpoint":"992","mobile_breakpoint":"768"};
</script>
<script src='https://automationbridge.com/wp-content/themes/bb-theme/js/theme.js?ver=1.7.9' id='fl-automator-js'></script>
<script src='https://automationbridge.com/wp-content/themes/bb-theme-child/inc/fl-ajax.js?ver=1.0' id='ajax-script-js'></script>
<script src='https://automationbridge.com/wp-includes/js/wp-embed.min.js?ver=5.8.1' id='wp-embed-js'></script>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-N54M99');</script>
<!-- End Google Tag Manager -->

</body>
</html>
