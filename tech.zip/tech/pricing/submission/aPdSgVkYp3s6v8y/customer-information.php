<iframe
  src="https://checkoutpage.co/c/bandr/Thank-You!"
  width="100%"
  height="1000"
  frameborder="0"
></iframe>
  <!-- Google Analytics -->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-213153441-1">
</script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-213153441-1');
</script>
  <!-- Google Analytics -->