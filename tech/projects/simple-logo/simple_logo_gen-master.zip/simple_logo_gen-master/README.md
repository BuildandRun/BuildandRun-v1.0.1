[![Latest release](https://img.shields.io/github/v/release/creecros/simple_logo_gen.svg?display_name=tag&include_prereleases&sort=semver)](https://github.com/creecros/simple_logo_gen/releases)
[![GitHub license](https://img.shields.io/github/license/Naereen/StrapDown.js.svg)](https://github.com/creecros/simple_logo_gen/blob/master/LICENSE)
[![Maintenance](https://img.shields.io/badge/Maintained%3F-yes-green.svg)](https://github.com/creecros/simple_logo_gen/graphs/contributors)
[![Open Source Love](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)]()
[![Downloads](https://img.shields.io/github/downloads/creecros/simple_logo_gen/total.svg)](https://github.com/creecros/simple_logo_gen/releases)


# Simple logo gen (Beta)
A simple logo generator using fontawesome.
https://creecros.github.io/simple_logo_gen/

![image](https://user-images.githubusercontent.com/26339368/55569084-ecf14f80-56ce-11e9-9fd5-8d8ee03a257e.png)

# To-do list
- [x] Multiple Logo Styles
- [x] Incorporate a nice Icon Picker
- [x] Effects
- [x] More fonts

# Collaborators welcome!
